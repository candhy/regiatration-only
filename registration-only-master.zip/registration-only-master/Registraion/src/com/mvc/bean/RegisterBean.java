package com.mvc.bean;

public class RegisterBean {

	 private String studentName;
	 private String studentDept;
	 private String marks;
	 private String phoneNumber;
	 private String percentage;
	 
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentDept() {
		return studentDept;
	}
	public void setStudentDept(String studentDept) {
		this.studentDept = studentDept;
	}
	public String getMarks() {
		return marks;
	}
	public void setMarks(String marks) {
		this.marks = marks;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getPercentage() {
		return percentage;
	}
	public void setPercentage(String percentage2) {
		this.percentage = percentage2;
	}
	

}
